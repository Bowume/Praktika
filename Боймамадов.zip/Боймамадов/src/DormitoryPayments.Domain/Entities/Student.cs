namespace DormitoryPayments.Domain.Entities;

public sealed class Student
{
    public int Id { get; set; }
    public string StudentNumber { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string? Patronymic { get; set; }
    public string GroupName { get; set; } = string.Empty;
    public string? Phone { get; set; }
    public string? Email { get; set; }
    public bool IsActive { get; set; } = true;

    public ICollection<Accommodation> Accommodations { get; set; } = new List<Accommodation>();
    public ICollection<Accrual> Accruals { get; set; } = new List<Accrual>();
    public ICollection<Payment> Payments { get; set; } = new List<Payment>();

    public string FullName => string.Join(
        " ",
        new[] { LastName, FirstName, Patronymic }.Where(value => !string.IsNullOrWhiteSpace(value)));

    public override string ToString() => $"{FullName} ({StudentNumber})";
}
