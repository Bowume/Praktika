using DormitoryPayments.Application.Students;
using DormitoryPayments.WinForms.UI;

namespace DormitoryPayments.WinForms.Forms;

internal sealed class StudentEditForm : EditDialogBase
{
    private readonly IStudentService _studentService;
    private readonly StudentInput _model;
    private readonly TextBox _number;
    private readonly TextBox _lastName;
    private readonly TextBox _firstName;
    private readonly TextBox _patronymic;
    private readonly TextBox _group;
    private readonly TextBox _phone;
    private readonly TextBox _email;
    private readonly CheckBox _isActive;

    public StudentEditForm(IStudentService studentService, StudentInput? model)
        : base(
            model?.Id is null ? "Новый студент" : "Карточка студента",
            "Заполните обязательные поля и контактные данные",
            new Size(650, 650))
    {
        _studentService = studentService;
        _model = model ?? new StudentInput(null, "", "", "", null, "", null, null);

        BodyPanel.Controls.Add(FieldLabel("Номер студенческого билета *", 28, 24, 270));
        _number = TextField(28, 47, 270, _model.StudentNumber);
        BodyPanel.Controls.Add(_number);

        BodyPanel.Controls.Add(FieldLabel("Учебная группа *", 326, 24, 270));
        _group = TextField(326, 47, 270, _model.GroupName);
        BodyPanel.Controls.Add(_group);

        BodyPanel.Controls.Add(FieldLabel("Фамилия *", 28, 104, 270));
        _lastName = TextField(28, 127, 270, _model.LastName);
        BodyPanel.Controls.Add(_lastName);

        BodyPanel.Controls.Add(FieldLabel("Имя *", 326, 104, 270));
        _firstName = TextField(326, 127, 270, _model.FirstName);
        BodyPanel.Controls.Add(_firstName);

        BodyPanel.Controls.Add(FieldLabel("Отчество", 28, 184, 568));
        _patronymic = TextField(28, 207, 568, _model.Patronymic);
        BodyPanel.Controls.Add(_patronymic);

        BodyPanel.Controls.Add(FieldLabel("Телефон", 28, 264, 270));
        _phone = TextField(28, 287, 270, _model.Phone);
        BodyPanel.Controls.Add(_phone);

        BodyPanel.Controls.Add(FieldLabel("Электронная почта", 326, 264, 270));
        _email = TextField(326, 287, 270, _model.Email);
        BodyPanel.Controls.Add(_email);

        var hint = new RoundedPanel
        {
            Location = new Point(28, 352),
            Size = new Size(568, 76),
            CornerRadius = 12,
            BorderWidth = 0,
            BackColor = Theme.PrimarySoft,
            Padding = new Padding(16)
        };
        hint.Controls.Add(new Label
        {
            Text = "Номер билета должен быть уникальным. Заселение студента\nоформляется отдельно в разделе «Жилой фонд».",
            Dock = DockStyle.Fill,
            ForeColor = Theme.PrimaryHover,
            BackColor = Color.Transparent,
            Font = Theme.Font(9),
            TextAlign = ContentAlignment.MiddleLeft
        });
        BodyPanel.Controls.Add(hint);

        _isActive = new CheckBox
        {
            Text = "Активная карточка студента",
            Checked = _model.IsActive,
            AutoSize = true,
            Location = new Point(30, 457),
            ForeColor = Theme.Text,
            Font = Theme.Font(9.5f),
            Visible = _model.Id is not null
        };
        BodyPanel.Controls.Add(_isActive);

        SaveButton.Click += async (_, _) => await RunSaveAsync(SaveAsync);
    }

    private async Task SaveAsync()
    {
        var input = new StudentInput(
            _model.Id,
            _number.Text,
            _lastName.Text,
            _firstName.Text,
            _patronymic.Text,
            _group.Text,
            _phone.Text,
            _email.Text,
            _model.Id is null || _isActive.Checked);
        await _studentService.SaveAsync(input);
    }
}
