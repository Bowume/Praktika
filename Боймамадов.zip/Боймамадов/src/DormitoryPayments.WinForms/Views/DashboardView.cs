using System.ComponentModel;
using DormitoryPayments.Application.Dashboard;
using DormitoryPayments.Application.Integrations;
using DormitoryPayments.Application.Security;
using DormitoryPayments.WinForms.UI;

namespace DormitoryPayments.WinForms.Views;

internal sealed class DashboardView : UserControl
{
    private readonly IDashboardService _dashboardService;
    private readonly ICurrencyRateService _currencyRateService;
    private readonly Label _studentsValue;
    private readonly Label _roomsValue;
    private readonly Label _accruedValue;
    private readonly Label _debtValue;
    private readonly Label _occupancyCaption;
    private readonly DataGridView _recentPayments = new();
    private readonly FlowLayoutPanel _ratesPanel;
    private readonly Label _ratesStatus;

    public DashboardView(
        IDashboardService dashboardService,
        ICurrencyRateService currencyRateService,
        IUserSession session)
    {
        _dashboardService = dashboardService;
        _currencyRateService = currencyRateService;
        Dock = DockStyle.Fill;
        BackColor = Theme.Canvas;

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            BackColor = Theme.Canvas,
            ColumnCount = 1,
            RowCount = 3,
            Margin = Padding.Empty,
            Padding = Padding.Empty
        };
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 138));
        layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 164));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(layout);

        var welcome = new RoundedPanel
        {
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 0, 0, 14),
            CornerRadius = 18,
            BorderWidth = 0,
            BackColor = Theme.Primary,
            Padding = new Padding(30)
        };
        welcome.Controls.Add(new Label
        {
            Text = $"Здравствуйте, {session.CurrentUser?.DisplayName}!",
            AutoSize = true,
            Location = new Point(30, 28),
            ForeColor = Color.White,
            BackColor = Color.Transparent,
            Font = Theme.Font(18, FontStyle.Bold)
        });
        welcome.Controls.Add(new Label
        {
            Text = "Финансовая картина общежития обновлена по данным SQL Server.",
            AutoSize = true,
            Location = new Point(32, 69),
            ForeColor = Color.FromArgb(224, 231, 255),
            BackColor = Color.Transparent,
            Font = Theme.Font(10)
        });
        var badge = new RoundedPanel
        {
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
            Size = new Size(194, 40),
            CornerRadius = 12,
            BorderWidth = 0,
            BackColor = Color.FromArgb(36, Color.White),
            Padding = new Padding(12)
        };
        badge.Controls.Add(new Label
        {
            Text = "●  Система работает",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.White,
            BackColor = Color.Transparent,
            Font = Theme.Font(9, FontStyle.Bold)
        });
        welcome.Controls.Add(badge);
        welcome.Resize += (_, _) => badge.Location = new Point(welcome.ClientSize.Width - badge.Width - 28, 38);
        layout.Controls.Add(welcome, 0, 0);

        var cards = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 4,
            RowCount = 1,
            BackColor = Theme.Canvas,
            Margin = Padding.Empty,
            Padding = new Padding(0, 2, 0, 16)
        };
        for (var index = 0; index < 4; index++)
        {
            cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        }
        (_studentsValue, var studentsCard, _) = CreateStatCard("Студенты", Theme.Primary);
        (_roomsValue, var roomsCard, _occupancyCaption) = CreateStatCard("Жилой фонд", Theme.Accent);
        (_accruedValue, var accruedCard, _) = CreateStatCard("Начислено за месяц", Theme.Warning);
        (_debtValue, var debtCard, _) = CreateStatCard("Общая задолженность", Theme.Danger);
        cards.Controls.Add(studentsCard, 0, 0);
        cards.Controls.Add(roomsCard, 1, 0);
        cards.Controls.Add(accruedCard, 2, 0);
        cards.Controls.Add(debtCard, 3, 0);
        layout.Controls.Add(cards, 0, 1);

        var lower = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Theme.Canvas,
            Margin = Padding.Empty
        };
        lower.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 67));
        lower.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33));
        layout.Controls.Add(lower, 0, 2);

        var paymentsCard = new RoundedPanel
        {
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 0, 14, 0),
            CornerRadius = 16,
            BorderColor = Theme.Border,
            Padding = new Padding(20)
        };
        paymentsCard.Controls.Add(new Label
        {
            Text = "Последние платежи",
            Dock = DockStyle.Top,
            Height = 38,
            ForeColor = Theme.Text,
            Font = Theme.Font(12, FontStyle.Bold)
        });
        Theme.ConfigureGrid(_recentPayments);
        _recentPayments.Dock = DockStyle.Fill;
        _recentPayments.AutoGenerateColumns = false;
        _recentPayments.ColumnHeadersHeight = 40;
        _recentPayments.RowTemplate.Height = 39;
        _recentPayments.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Дата", DataPropertyName = "Date", FillWeight = 60, DefaultCellStyle = new DataGridViewCellStyle { Format = "dd.MM.yyyy" } });
        _recentPayments.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Студент", DataPropertyName = "StudentName", FillWeight = 125 });
        _recentPayments.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Документ", DataPropertyName = "DocumentNumber", FillWeight = 90 });
        _recentPayments.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Сумма", DataPropertyName = "Amount", FillWeight = 70, DefaultCellStyle = new DataGridViewCellStyle { Format = "N2", Alignment = DataGridViewContentAlignment.MiddleRight } });
        paymentsCard.Controls.Add(_recentPayments);
        _recentPayments.BringToFront();
        lower.Controls.Add(paymentsCard, 0, 0);

        var ratesCard = new RoundedPanel
        {
            Dock = DockStyle.Fill,
            Margin = Padding.Empty,
            CornerRadius = 16,
            BorderColor = Theme.Border,
            Padding = new Padding(22)
        };
        ratesCard.Controls.Add(new Label
        {
            Text = "Курсы валют ЦБ РФ",
            Dock = DockStyle.Top,
            Height = 30,
            ForeColor = Theme.Text,
            Font = Theme.Font(12, FontStyle.Bold)
        });
        _ratesStatus = new Label
        {
            Text = "Получаем актуальные данные…",
            Dock = DockStyle.Bottom,
            Height = 26,
            ForeColor = Theme.MutedText,
            Font = Theme.Font(8.5f),
            TextAlign = ContentAlignment.MiddleLeft
        };
        ratesCard.Controls.Add(_ratesStatus);
        _ratesPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            BackColor = Theme.Surface,
            Padding = new Padding(0, 8, 0, 0)
        };
        ratesCard.Controls.Add(_ratesPanel);
        _ratesPanel.BringToFront();
        lower.Controls.Add(ratesCard, 1, 0);

        Load += async (_, _) => await LoadDashboardAsync();
    }

    private static (Label Value, RoundedPanel Card, Label Caption) CreateStatCard(string title, Color accent)
    {
        var card = new RoundedPanel
        {
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 0, 12, 0),
            CornerRadius = 16,
            BorderColor = Theme.Border,
            Padding = new Padding(20)
        };
        card.Controls.Add(new Panel { Location = new Point(20, 21), Size = new Size(4, 80), BackColor = accent });
        card.Controls.Add(new Label
        {
            Text = title.ToUpperInvariant(),
            AutoSize = true,
            Location = new Point(38, 18),
            ForeColor = Theme.MutedText,
            Font = Theme.Font(7.5f, FontStyle.Bold)
        });
        var value = new Label
        {
            Text = "—",
            AutoSize = true,
            Location = new Point(36, 44),
            ForeColor = Theme.Text,
            Font = Theme.Font(18, FontStyle.Bold)
        };
        card.Controls.Add(value);
        var caption = new Label
        {
            Text = "Загрузка данных…",
            AutoSize = true,
            Location = new Point(38, 84),
            ForeColor = Theme.MutedText,
            Font = Theme.Font(8.5f)
        };
        card.Controls.Add(caption);
        return (value, card, caption);
    }

    private async Task LoadDashboardAsync()
    {
        try
        {
            var snapshotTask = _dashboardService.GetSnapshotAsync();
            var ratesTask = _currencyRateService.GetLatestRatesAsync();
            var snapshot = await snapshotTask;
            _studentsValue.Text = snapshot.ActiveStudents.ToString("N0");
            _studentsValue.Parent!.Controls.OfType<Label>().Last().Text = "Активные лицевые счета";
            _roomsValue.Text = snapshot.ActiveRooms.ToString("N0");
            _occupancyCaption.Text = $"Занято {snapshot.OccupiedPlaces} из {snapshot.TotalPlaces} мест";
            _accruedValue.Text = $"{snapshot.CurrentMonthAccrued:N0} ₽";
            _accruedValue.Parent!.Controls.OfType<Label>().Last().Text = $"Оплачено {snapshot.CurrentMonthPaid:N0} ₽";
            _debtValue.Text = $"{snapshot.TotalDebt:N0} ₽";
            _debtValue.Parent!.Controls.OfType<Label>().Last().Text = "По всем лицевым счетам";
            _recentPayments.DataSource = new BindingList<RecentPaymentItem>(snapshot.RecentPayments.ToList());

            var rates = await ratesTask;
            _ratesPanel.Controls.Clear();
            if (!rates.IsSuccess)
            {
                _ratesStatus.Text = rates.ErrorMessage;
                _ratesStatus.ForeColor = Theme.Warning;
                return;
            }
            foreach (var rate in rates.Rates)
            {
                var trend = rate.Value >= rate.PreviousValue ? "▲" : "▼";
                var color = rate.Value >= rate.PreviousValue ? Theme.Danger : Theme.Success;
                var row = new Panel { Width = 280, Height = 32, BackColor = Theme.Surface, Margin = new Padding(0, 0, 0, 1) };
                row.Controls.Add(new Label
                {
                    Text = rate.Code,
                    Location = new Point(0, 1),
                    Size = new Size(48, 28),
                    TextAlign = ContentAlignment.MiddleCenter,
                    BackColor = Theme.PrimarySoft,
                    ForeColor = Theme.Primary,
                    Font = Theme.Font(8, FontStyle.Bold)
                });
                row.Controls.Add(new Label
                {
                    Text = $"{rate.Value / rate.Nominal:N2} ₽",
                    AutoSize = true,
                    Location = new Point(62, 0),
                    ForeColor = Theme.Text,
                    Font = Theme.Font(10, FontStyle.Bold)
                });
                row.Controls.Add(new Label
                {
                    Text = $"{trend}  {rate.Name}",
                    AutoEllipsis = true,
                    Location = new Point(64, 17),
                    Size = new Size(205, 18),
                    ForeColor = color,
                    Font = Theme.Font(7)
                });
                _ratesPanel.Controls.Add(row);
            }
            _ratesStatus.Text = rates.RateDate is null
                ? "Справочные данные"
                : $"Курс на {rates.RateDate:dd.MM.yyyy}";
            _ratesStatus.ForeColor = Theme.MutedText;
        }
        catch (Exception exception)
        {
            _ratesStatus.Text = $"Данные временно недоступны: {exception.Message}";
            _ratesStatus.ForeColor = Theme.Warning;
        }
    }
}
