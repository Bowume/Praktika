using System.ComponentModel;
using DormitoryPayments.Application.Reporting;
using DormitoryPayments.Application.Security;
using DormitoryPayments.WinForms.Services;
using DormitoryPayments.WinForms.UI;
using Microsoft.Extensions.Configuration;

namespace DormitoryPayments.WinForms.Views;

internal sealed class ReportsView : UserControl
{
    private enum Section
    {
        Debts,
        Period,
        Analytics
    }

    private readonly IReportingService _service;
    private readonly ReportExportService _exportService;
    private readonly bool _canExport;
    private readonly DataGridView _grid = new();
    private readonly Panel _analyticsPanel;
    private readonly FinancialChart _chart;
    private readonly TextBox _search = new();
    private readonly RoundedPanel _searchPanel;
    private readonly DateTimePicker _asOf;
    private readonly NumericUpDown _annualRate;
    private readonly DateTimePicker _from;
    private readonly DateTimePicker _to;
    private readonly ComboBox _student;
    private readonly RoundedButton _excelButton;
    private readonly RoundedButton _pdfButton;
    private readonly RoundedButton _receiptButton;
    private readonly Label _summary;
    private readonly Label _averageLabel;
    private readonly Label _medianLabel;
    private readonly Label _varianceLabel;
    private readonly Label _maximumLabel;
    private readonly Dictionary<Section, RoundedButton> _sectionButtons = [];
    private readonly System.Windows.Forms.Timer _searchTimer;
    private IReadOnlyList<DebtRow> _debtRows = [];
    private IReadOnlyList<PeriodSummaryRow> _periodRows = [];
    private Section _section = Section.Debts;

    public ReportsView(
        IReportingService service,
        ReportExportService exportService,
        IUserSession session,
        IConfiguration configuration)
    {
        _service = service;
        _exportService = exportService;
        _canExport = session.HasPermission(Permission.ExportReports);
        _searchTimer = new System.Windows.Forms.Timer { Interval = 350 };
        Dock = DockStyle.Fill;
        BackColor = Theme.Canvas;

        var card = new RoundedPanel { Dock = DockStyle.Fill, CornerRadius = 16, BorderColor = Theme.Border, Padding = Padding.Empty };
        Controls.Add(card);
        var sections = new Panel { Dock = DockStyle.Top, Height = 66, BackColor = Theme.Surface, Padding = new Padding(22, 13, 22, 11) };
        card.Controls.Add(sections);
        var sectionFlow = new FlowLayoutPanel { Dock = DockStyle.Left, Width = 560, WrapContents = false, BackColor = Theme.Surface };
        sections.Controls.Add(sectionFlow);
        AddSectionButton(sectionFlow, Section.Debts, "Задолженность");
        AddSectionButton(sectionFlow, Section.Period, "Отчёт за период");
        AddSectionButton(sectionFlow, Section.Analytics, "Аналитика");

        var toolbar = new Panel { Dock = DockStyle.Top, Height = 82, BackColor = Color.FromArgb(251, 252, 254), Padding = new Padding(22, 19, 22, 17) };
        card.Controls.Add(toolbar);
        toolbar.BringToFront();
        _searchPanel = UiFactory.CreateSearchPanel(_search, 250);
        _searchPanel.Location = new Point(22, 19);
        toolbar.Controls.Add(_searchPanel);
        _search.TextChanged += (_, _) => { _searchTimer.Stop(); _searchTimer.Start(); };

        _asOf = CreateDatePicker(new Point(290, 20), DateTime.Today, 132);
        _asOf.ValueChanged += async (_, _) => await LoadDataAsync();
        toolbar.Controls.Add(_asOf);
        _annualRate = new NumericUpDown
        {
            Location = new Point(434, 20),
            Size = new Size(86, 34),
            DecimalPlaces = 2,
            Minimum = 0,
            Maximum = 100,
            Value = Math.Clamp(configuration.GetValue<decimal?>("DebtCalculation:AnnualPenaltyRate") * 100 ?? 10, 0, 100),
            Font = Theme.Font(9.5f)
        };
        _annualRate.ValueChanged += async (_, _) => await LoadDataAsync();
        toolbar.Controls.Add(_annualRate);
        var percentLabel = new Label
        {
            Text = "% годовых",
            AutoSize = true,
            Location = new Point(522, 29),
            ForeColor = Theme.MutedText,
            Font = Theme.Font(8.5f)
        };
        toolbar.Controls.Add(percentLabel);
        _annualRate.Tag = percentLabel;

        _from = CreateDatePicker(new Point(22, 20), DateTime.Today.AddMonths(-5), 132);
        _to = CreateDatePicker(new Point(166, 20), DateTime.Today, 132);
        _from.ValueChanged += async (_, _) => await LoadDataAsync();
        _to.ValueChanged += async (_, _) => await LoadDataAsync();
        toolbar.Controls.Add(_from);
        toolbar.Controls.Add(_to);
        _student = new ComboBox
        {
            Location = new Point(310, 20),
            Size = new Size(280, 34),
            DropDownStyle = ComboBoxStyle.DropDownList,
            Font = Theme.Font(9.5f)
        };
        _student.SelectedIndexChanged += async (_, _) =>
        {
            if (_section == Section.Period && _student.DataSource is not null)
            {
                await LoadDataAsync();
            }
        };
        toolbar.Controls.Add(_student);

        var actions = new FlowLayoutPanel
        {
            Dock = DockStyle.Right,
            Width = _canExport ? 420 : 112,
            FlowDirection = FlowDirection.RightToLeft,
            WrapContents = false,
            BackColor = toolbar.BackColor
        };
        toolbar.Controls.Add(actions);
        var refresh = UiFactory.CreateSecondaryButton("Обновить", 104);
        refresh.Click += async (_, _) => await LoadDataAsync();
        actions.Controls.Add(refresh);
        _receiptButton = UiFactory.CreatePrimaryButton("Квитанция PDF", 132);
        _receiptButton.Click += ReceiptButton_Click;
        actions.Controls.Add(_receiptButton);
        _pdfButton = UiFactory.CreateSecondaryButton("PDF", 72);
        _pdfButton.Click += PdfButton_Click;
        actions.Controls.Add(_pdfButton);
        _excelButton = UiFactory.CreateSecondaryButton("Excel", 78);
        _excelButton.Click += ExcelButton_Click;
        actions.Controls.Add(_excelButton);

        Theme.ConfigureGrid(_grid);
        _grid.Dock = DockStyle.Fill;
        _grid.AutoGenerateColumns = false;
        card.Controls.Add(_grid);
        _grid.BringToFront();

        _analyticsPanel = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Canvas, Padding = new Padding(0, 0, 0, 8), Visible = false };
        var statistics = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 142,
            ColumnCount = 4,
            RowCount = 1,
            BackColor = Theme.Canvas,
            Padding = new Padding(0, 10, 0, 12)
        };
        for (var index = 0; index < 4; index++)
        {
            statistics.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        }
        (_averageLabel, var averageCard) = CreateStatisticCard("Среднее начисление", Theme.Primary);
        (_medianLabel, var medianCard) = CreateStatisticCard("Медиана оплат", Theme.Accent);
        (_varianceLabel, var varianceCard) = CreateStatisticCard("Дисперсия долга", Theme.Warning);
        (_maximumLabel, var maximumCard) = CreateStatisticCard("Максимальный долг", Theme.Danger);
        statistics.Controls.Add(averageCard, 0, 0);
        statistics.Controls.Add(medianCard, 1, 0);
        statistics.Controls.Add(varianceCard, 2, 0);
        statistics.Controls.Add(maximumCard, 3, 0);
        _analyticsPanel.Controls.Add(statistics);
        var chartCard = new RoundedPanel { Dock = DockStyle.Fill, CornerRadius = 14, BorderColor = Theme.Border, Padding = new Padding(14) };
        _chart = new FinancialChart { Dock = DockStyle.Fill };
        chartCard.Controls.Add(_chart);
        _analyticsPanel.Controls.Add(chartCard);
        chartCard.BringToFront();
        card.Controls.Add(_analyticsPanel);
        _analyticsPanel.BringToFront();

        var footer = new Panel { Dock = DockStyle.Bottom, Height = 58, BackColor = Theme.Surface, Padding = new Padding(22, 10, 22, 10) };
        _summary = new Label { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, ForeColor = Theme.MutedText, Font = Theme.Font(9) };
        footer.Controls.Add(_summary);
        card.Controls.Add(footer);
        footer.BringToFront();

        _searchTimer.Tick += async (_, _) => { _searchTimer.Stop(); await LoadDataAsync(); };
        UpdateSectionAppearance();
        ConfigureColumns();
        Load += async (_, _) =>
        {
            await LoadStudentsAsync();
            await LoadDataAsync();
        };
    }

    private static DateTimePicker CreateDatePicker(Point location, DateTime value, int width) => new()
    {
        Location = location,
        Size = new Size(width, 34),
        Format = DateTimePickerFormat.Custom,
        CustomFormat = "dd.MM.yyyy",
        Value = value,
        Font = Theme.Font(9.5f)
    };

    private static (Label ValueLabel, RoundedPanel Card) CreateStatisticCard(string title, Color accent)
    {
        var card = new RoundedPanel
        {
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 0, 12, 0),
            CornerRadius = 14,
            BorderColor = Theme.Border,
            Padding = new Padding(18)
        };
        card.Controls.Add(new Panel { Location = new Point(18, 20), Size = new Size(4, 72), BackColor = accent });
        card.Controls.Add(new Label
        {
            Text = title.ToUpperInvariant(),
            AutoSize = true,
            Location = new Point(34, 18),
            ForeColor = Theme.MutedText,
            Font = Theme.Font(7.5f, FontStyle.Bold)
        });
        var value = new Label
        {
            Text = "—",
            AutoSize = true,
            Location = new Point(32, 49),
            ForeColor = Theme.Text,
            Font = Theme.Font(16, FontStyle.Bold)
        };
        card.Controls.Add(value);
        return (value, card);
    }

    private void AddSectionButton(FlowLayoutPanel host, Section section, string text)
    {
        var button = UiFactory.CreateSecondaryButton(text, 164);
        button.Click += async (_, _) =>
        {
            _section = section;
            UpdateSectionAppearance();
            ConfigureColumns();
            await LoadDataAsync();
        };
        host.Controls.Add(button);
        _sectionButtons[section] = button;
    }

    private void UpdateSectionAppearance()
    {
        foreach (var pair in _sectionButtons)
        {
            var selected = pair.Key == _section;
            pair.Value.NormalColor = selected ? Theme.PrimarySoft : Color.FromArgb(241, 245, 249);
            pair.Value.HoverColor = selected ? Theme.PrimarySoft : Color.FromArgb(226, 232, 240);
            pair.Value.ForeColor = selected ? Theme.Primary : Theme.Text;
        }
        var debts = _section == Section.Debts;
        var period = _section == Section.Period;
        _searchPanel.Visible = debts;
        _asOf.Visible = debts;
        _annualRate.Visible = debts;
        if (_annualRate.Tag is Control rateLabel)
        {
            rateLabel.Visible = debts;
        }
        _from.Visible = !debts;
        _to.Visible = !debts;
        _student.Visible = period;
        _grid.Visible = _section != Section.Analytics;
        _analyticsPanel.Visible = _section == Section.Analytics;
        _receiptButton.Visible = debts && _canExport;
        _excelButton.Visible = period && _canExport;
        _pdfButton.Visible = period && _canExport;
    }

    private void ConfigureColumns()
    {
        _grid.DataSource = null;
        _grid.Columns.Clear();
        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Id", DataPropertyName = "StudentId", Visible = false });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "№ билета", DataPropertyName = "StudentNumber", FillWeight = 75 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Студент", DataPropertyName = "StudentName", FillWeight = 140 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Группа", DataPropertyName = "GroupName", FillWeight = 65 });
        if (_section == Section.Debts)
        {
            AddMoneyColumn("Начислено", "Accrued");
            AddMoneyColumn("Оплачено", "Paid");
            AddMoneyColumn("Долг", "PrincipalDebt");
            AddMoneyColumn("Аванс", "Advance");
            AddMoneyColumn("Пени", "Penalty");
            AddMoneyColumn("К оплате", "TotalPayable");
        }
        else if (_section == Section.Period)
        {
            AddMoneyColumn("Начислено", "Accrued");
            AddMoneyColumn("Оплачено", "Paid");
            AddMoneyColumn("Разница", "Difference");
        }
    }

    private void AddMoneyColumn(string header, string property) =>
        _grid.Columns.Add(new DataGridViewTextBoxColumn
        {
            HeaderText = header,
            DataPropertyName = property,
            FillWeight = 75,
            DefaultCellStyle = new DataGridViewCellStyle { Format = "N2", Alignment = DataGridViewContentAlignment.MiddleRight }
        });

    private async Task LoadStudentsAsync()
    {
        var options = await _service.GetStudentOptionsAsync();
        var filters = new List<StudentFilter> { new(null, "Все студенты") };
        filters.AddRange(options.Select(item => new StudentFilter(item.Id, item.DisplayName)));
        _student.DataSource = filters;
    }

    private async Task LoadDataAsync()
    {
        Enabled = false;
        try
        {
            var from = DateOnly.FromDateTime(_from.Value);
            var to = DateOnly.FromDateTime(_to.Value);
            switch (_section)
            {
                case Section.Debts:
                    _debtRows = await _service.GetDebtsAsync(
                        _search.Text,
                        DateOnly.FromDateTime(_asOf.Value),
                        _annualRate.Value / 100m);
                    _grid.DataSource = new BindingList<DebtRow>(_debtRows.ToList());
                    _summary.Text = $"Лицевых счетов: {_debtRows.Count}  •  Основной долг: {_debtRows.Sum(item => item.PrincipalDebt):N2} руб.  •  Пени: {_debtRows.Sum(item => item.Penalty):N2} руб.";
                    break;
                case Section.Period:
                    var studentId = (_student.SelectedItem as StudentFilter)?.Id;
                    _periodRows = await _service.GetPeriodSummaryAsync(from, to, studentId);
                    _grid.DataSource = new BindingList<PeriodSummaryRow>(_periodRows.ToList());
                    _summary.Text = $"Строк: {_periodRows.Count}  •  Начислено: {_periodRows.Sum(item => item.Accrued):N2} руб.  •  Оплачено: {_periodRows.Sum(item => item.Paid):N2} руб.";
                    break;
                case Section.Analytics:
                    var analytics = await _service.GetAnalyticsAsync(from, to);
                    _chart.Data = analytics.Months;
                    _averageLabel.Text = $"{analytics.AccrualStatistics.Mean:N2} ₽";
                    _medianLabel.Text = $"{analytics.PaymentStatistics.Median:N2} ₽";
                    _varianceLabel.Text = $"{analytics.DebtStatistics.Variance:N2}";
                    _maximumLabel.Text = $"{analytics.DebtStatistics.Maximum:N2} ₽";
                    _summary.Text = $"Месяцев: {analytics.Months.Count}  •  Среднее начисление: {analytics.AccrualStatistics.Mean:N2} руб.  •  Медиана оплат: {analytics.PaymentStatistics.Median:N2} руб.";
                    break;
            }
        }
        catch (Exception exception)
        {
            UiFactory.ShowError(this, exception);
        }
        finally
        {
            Enabled = true;
        }
    }

    private void ExcelButton_Click(object? sender, EventArgs eventArgs)
    {
        if (_periodRows.Count == 0)
        {
            MessageBox.Show(this, "Нет данных для экспорта.", "Campus Pay", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var dialog = new SaveFileDialog
        {
            Filter = "Книга Excel (*.xlsx)|*.xlsx",
            FileName = $"Начисления_и_оплаты_{_from.Value:yyyyMMdd}_{_to.Value:yyyyMMdd}.xlsx"
        };
        if (dialog.ShowDialog(this) != DialogResult.OK)
        {
            return;
        }
        try
        {
            _exportService.ExportPeriodToExcel(
                dialog.FileName,
                _periodRows,
                DateOnly.FromDateTime(_from.Value),
                DateOnly.FromDateTime(_to.Value));
            ShowExportCompleted(dialog.FileName);
        }
        catch (Exception exception)
        {
            UiFactory.ShowError(this, exception);
        }
    }

    private void PdfButton_Click(object? sender, EventArgs eventArgs)
    {
        if (_periodRows.Count == 0)
        {
            MessageBox.Show(this, "Нет данных для экспорта.", "Campus Pay", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var dialog = new SaveFileDialog
        {
            Filter = "Документ PDF (*.pdf)|*.pdf",
            FileName = $"Начисления_и_оплаты_{_from.Value:yyyyMMdd}_{_to.Value:yyyyMMdd}.pdf"
        };
        if (dialog.ShowDialog(this) != DialogResult.OK)
        {
            return;
        }
        try
        {
            _exportService.ExportPeriodToPdf(
                dialog.FileName,
                _periodRows,
                DateOnly.FromDateTime(_from.Value),
                DateOnly.FromDateTime(_to.Value));
            ShowExportCompleted(dialog.FileName);
        }
        catch (Exception exception)
        {
            UiFactory.ShowError(this, exception);
        }
    }

    private async void ReceiptButton_Click(object? sender, EventArgs eventArgs)
    {
        var studentId = UiFactory.SelectedId(_grid);
        if (studentId is null)
        {
            MessageBox.Show(this, "Выберите студента в таблице задолженности.", "Campus Pay", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var dialog = new SaveFileDialog
        {
            Filter = "Документ PDF (*.pdf)|*.pdf",
            FileName = $"Квитанция_{studentId}_{DateTime.Today:yyyyMMdd}.pdf"
        };
        if (dialog.ShowDialog(this) != DialogResult.OK)
        {
            return;
        }
        try
        {
            var asOf = DateOnly.FromDateTime(_asOf.Value);
            var statement = await _service.GetStudentStatementAsync(
                studentId.Value,
                asOf.AddMonths(-5),
                asOf,
                asOf,
                _annualRate.Value / 100m);
            _exportService.ExportReceipt(dialog.FileName, statement);
            ShowExportCompleted(dialog.FileName);
        }
        catch (Exception exception)
        {
            UiFactory.ShowError(this, exception);
        }
    }

    private void ShowExportCompleted(string path)
    {
        MessageBox.Show(this, $"Файл сохранён:\n{path}", "Экспорт завершён", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private sealed record StudentFilter(int? Id, string DisplayName)
    {
        public override string ToString() => DisplayName;
    }
}
