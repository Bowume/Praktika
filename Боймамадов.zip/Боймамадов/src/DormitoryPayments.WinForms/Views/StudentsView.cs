using System.ComponentModel;
using DormitoryPayments.Application.Security;
using DormitoryPayments.Application.Students;
using DormitoryPayments.WinForms.Forms;
using DormitoryPayments.WinForms.UI;

namespace DormitoryPayments.WinForms.Views;

internal sealed class StudentsView : UserControl
{
    private readonly IStudentService _studentService;
    private readonly bool _canManage;
    private readonly TextBox _searchTextBox = new();
    private readonly CheckBox _includeInactive;
    private readonly DataGridView _grid = new();
    private readonly Label _summaryLabel;
    private readonly Label _pageLabel;
    private readonly RoundedButton _previousButton;
    private readonly RoundedButton _nextButton;
    private readonly System.Windows.Forms.Timer _searchTimer;
    private int _currentPage = 1;
    private const int PageSize = 20;

    public StudentsView(IStudentService studentService, IUserSession session)
    {
        _studentService = studentService;
        _canManage = session.HasPermission(Permission.ManageStudents);
        _searchTimer = new System.Windows.Forms.Timer { Interval = 350 };
        Dock = DockStyle.Fill;
        BackColor = Theme.Canvas;

        var card = new RoundedPanel
        {
            Dock = DockStyle.Fill,
            CornerRadius = 16,
            BorderColor = Theme.Border,
            Padding = Padding.Empty
        };
        Controls.Add(card);

        var toolbar = new Panel
        {
            Dock = DockStyle.Top,
            Height = 78,
            BackColor = Theme.Surface,
            Padding = new Padding(22, 18, 22, 16)
        };
        card.Controls.Add(toolbar);
        var searchPanel = UiFactory.CreateSearchPanel(_searchTextBox, 260);
        searchPanel.Location = new Point(22, 18);
        toolbar.Controls.Add(searchPanel);
        _searchTextBox.TextChanged += (_, _) =>
        {
            _searchTimer.Stop();
            _searchTimer.Start();
        };

        _includeInactive = new CheckBox
        {
            Text = "Показывать архив",
            AutoSize = true,
            Location = new Point(300, 29),
            ForeColor = Theme.MutedText,
            Font = Theme.Font(9),
            Cursor = Cursors.Hand
        };
        _includeInactive.CheckedChanged += async (_, _) =>
        {
            _currentPage = 1;
            await LoadDataAsync();
        };
        toolbar.Controls.Add(_includeInactive);

        var actions = new FlowLayoutPanel
        {
            Dock = DockStyle.Right,
            Width = _canManage ? 420 : 100,
            FlowDirection = FlowDirection.RightToLeft,
            WrapContents = false,
            BackColor = Theme.Surface,
            Padding = Padding.Empty
        };
        toolbar.Controls.Add(actions);
        var refreshButton = UiFactory.CreateSecondaryButton("Обновить", 90);
        refreshButton.Click += async (_, _) => await LoadDataAsync();
        actions.Controls.Add(refreshButton);
        if (_canManage)
        {
            var archiveButton = UiFactory.CreateDangerButton("В архив", 90);
            archiveButton.Click += ArchiveButton_Click;
            actions.Controls.Add(archiveButton);
            var editButton = UiFactory.CreateSecondaryButton("Изменить", 90);
            editButton.Click += EditButton_Click;
            actions.Controls.Add(editButton);
            var addButton = UiFactory.CreatePrimaryButton("+  Добавить", 112);
            addButton.Click += AddButton_Click;
            actions.Controls.Add(addButton);
        }

        Theme.ConfigureGrid(_grid);
        _grid.Dock = DockStyle.Fill;
        _grid.AutoGenerateColumns = false;
        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Id", DataPropertyName = "Id", Visible = false });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "№ билета", DataPropertyName = "StudentNumber", FillWeight = 80 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Ф. И. О.", DataPropertyName = "FullName", FillWeight = 150 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Группа", DataPropertyName = "GroupName", FillWeight = 70 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Проживание", DataPropertyName = "Residence", FillWeight = 145 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Телефон", DataPropertyName = "Phone", FillWeight = 100 });
        _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Активен", DataPropertyName = "IsActive", FillWeight = 55 });
        _grid.CellDoubleClick += (_, eventArgs) =>
        {
            if (_canManage && eventArgs.RowIndex >= 0)
            {
                EditButton_Click(this, EventArgs.Empty);
            }
        };
        card.Controls.Add(_grid);
        _grid.BringToFront();

        var footer = new Panel
        {
            Dock = DockStyle.Bottom,
            Height = 64,
            BackColor = Theme.Surface,
            Padding = new Padding(22, 11, 22, 11)
        };
        card.Controls.Add(footer);
        footer.BringToFront();
        _summaryLabel = new Label
        {
            Dock = DockStyle.Left,
            Width = 350,
            TextAlign = ContentAlignment.MiddleLeft,
            ForeColor = Theme.MutedText,
            Font = Theme.Font(9)
        };
        footer.Controls.Add(_summaryLabel);

        var pager = new FlowLayoutPanel
        {
            Dock = DockStyle.Right,
            Width = 330,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            BackColor = Theme.Surface
        };
        footer.Controls.Add(pager);
        _previousButton = UiFactory.CreateSecondaryButton("← Назад", 96);
        _previousButton.Click += async (_, _) =>
        {
            _currentPage = Math.Max(1, _currentPage - 1);
            await LoadDataAsync();
        };
        pager.Controls.Add(_previousButton);
        _pageLabel = new Label
        {
            Size = new Size(112, 42),
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Theme.Text,
            Font = Theme.Font(9, FontStyle.Bold)
        };
        pager.Controls.Add(_pageLabel);
        _nextButton = UiFactory.CreateSecondaryButton("Далее →", 96);
        _nextButton.Click += async (_, _) =>
        {
            _currentPage++;
            await LoadDataAsync();
        };
        pager.Controls.Add(_nextButton);

        _searchTimer.Tick += async (_, _) =>
        {
            _searchTimer.Stop();
            _currentPage = 1;
            await LoadDataAsync();
        };
        Load += async (_, _) => await LoadDataAsync();
    }

    private async Task LoadDataAsync()
    {
        Enabled = false;
        try
        {
            var result = await _studentService.GetPageAsync(
                _searchTextBox.Text,
                _includeInactive.Checked,
                _currentPage,
                PageSize);
            if (_currentPage > result.TotalPages)
            {
                _currentPage = result.TotalPages;
                result = await _studentService.GetPageAsync(
                    _searchTextBox.Text,
                    _includeInactive.Checked,
                    _currentPage,
                    PageSize);
            }
            _grid.DataSource = new BindingList<StudentRow>(result.Items.ToList());
            _summaryLabel.Text = $"Найдено записей: {result.TotalCount}";
            _pageLabel.Text = $"{result.Page} из {result.TotalPages}";
            _previousButton.Enabled = result.Page > 1;
            _nextButton.Enabled = result.Page < result.TotalPages;
        }
        catch (Exception exception)
        {
            UiFactory.ShowError(this, exception);
        }
        finally
        {
            Enabled = true;
        }
    }

    private void AddButton_Click(object? sender, EventArgs eventArgs)
    {
        using var form = new StudentEditForm(_studentService, null);
        if (form.ShowDialog(this) == DialogResult.OK)
        {
            _ = LoadDataAsync();
        }
    }

    private async void EditButton_Click(object? sender, EventArgs eventArgs)
    {
        var id = UiFactory.SelectedId(_grid);
        if (id is null)
        {
            MessageBox.Show(this, "Выберите студента в таблице.", "Campus Pay", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        try
        {
            var model = await _studentService.GetAsync(id.Value);
            if (model is null)
            {
                throw new InvalidOperationException("Карточка студента не найдена.");
            }
            using var form = new StudentEditForm(_studentService, model);
            if (form.ShowDialog(this) == DialogResult.OK)
            {
                await LoadDataAsync();
            }
        }
        catch (Exception exception)
        {
            UiFactory.ShowError(this, exception);
        }
    }

    private async void ArchiveButton_Click(object? sender, EventArgs eventArgs)
    {
        var id = UiFactory.SelectedId(_grid);
        if (id is null)
        {
            MessageBox.Show(this, "Выберите студента в таблице.", "Campus Pay", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        if (MessageBox.Show(
                this,
                "Перевести выбранную карточку в архив? Финансовая история будет сохранена.",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) != DialogResult.Yes)
        {
            return;
        }
        try
        {
            await _studentService.ArchiveAsync(id.Value);
            await LoadDataAsync();
        }
        catch (Exception exception)
        {
            UiFactory.ShowError(this, exception);
        }
    }
}
