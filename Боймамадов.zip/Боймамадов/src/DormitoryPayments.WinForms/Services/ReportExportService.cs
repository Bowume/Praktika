using ClosedXML.Excel;
using DormitoryPayments.Application.Reporting;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace DormitoryPayments.WinForms.Services;

internal sealed class ReportExportService
{
    private const string Primary = "4F46E5";
    private const string Text = "1E293B";
    private const string Muted = "64748B";
    private const string Border = "E2E8F0";

    public void ExportPeriodToExcel(
        string path,
        IReadOnlyList<PeriodSummaryRow> rows,
        DateOnly from,
        DateOnly to)
    {
        using var workbook = new XLWorkbook();
        var sheet = workbook.Worksheets.Add("Начисления и оплаты");
        sheet.Cell("A1").Value = "CAMPUS PAY";
        sheet.Range("A1:G1").Merge();
        sheet.Range("A1:G1").Style
            .Font.SetBold()
            .Font.SetFontSize(18)
            .Font.SetFontColor(XLColor.FromHtml("#4F46E5"));
        sheet.Cell("A2").Value = "Начисления и оплаты за период";
        sheet.Range("A2:G2").Merge();
        sheet.Range("A2:G2").Style.Font.SetBold().Font.SetFontSize(14);
        sheet.Cell("A3").Value = $"Период: {from:dd.MM.yyyy} — {to:dd.MM.yyyy}";
        sheet.Range("A3:G3").Merge();

        var headers = new[] { "№ билета", "Студент", "Группа", "Начислено", "Оплачено", "Разница", "Состояние" };
        for (var column = 0; column < headers.Length; column++)
        {
            var cell = sheet.Cell(5, column + 1);
            cell.Value = headers[column];
            cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#4F46E5");
            cell.Style.Font.FontColor = XLColor.White;
            cell.Style.Font.Bold = true;
            cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
        }

        for (var index = 0; index < rows.Count; index++)
        {
            var row = rows[index];
            var excelRow = index + 6;
            sheet.Cell(excelRow, 1).Value = row.StudentNumber;
            sheet.Cell(excelRow, 2).Value = row.StudentName;
            sheet.Cell(excelRow, 3).Value = row.GroupName;
            sheet.Cell(excelRow, 4).Value = row.Accrued;
            sheet.Cell(excelRow, 5).Value = row.Paid;
            sheet.Cell(excelRow, 6).Value = row.Difference;
            sheet.Cell(excelRow, 7).Value = row.Difference switch
            {
                > 0 => "Задолженность",
                < 0 => "Аванс",
                _ => "Оплачено"
            };
        }

        var totalRow = rows.Count + 7;
        sheet.Cell(totalRow, 3).Value = "ИТОГО";
        sheet.Cell(totalRow, 4).Value = rows.Sum(item => item.Accrued);
        sheet.Cell(totalRow, 5).Value = rows.Sum(item => item.Paid);
        sheet.Cell(totalRow, 6).Value = rows.Sum(item => item.Difference);
        sheet.Range(totalRow, 3, totalRow, 7).Style.Font.Bold = true;
        sheet.Range(6, 4, totalRow, 6).Style.NumberFormat.Format = "# ##0.00 \"₽\"";
        sheet.Range(5, 1, totalRow, 7).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
        sheet.Range(5, 1, totalRow, 7).Style.Border.InsideBorder = XLBorderStyleValues.Hair;
        sheet.SheetView.FreezeRows(5);
        sheet.Columns().AdjustToContents(12, 42);
        sheet.PageSetup.PageOrientation = XLPageOrientation.Landscape;
        sheet.PageSetup.FitToPages(1, 0);
        workbook.SaveAs(path);
    }

    public void ExportPeriodToPdf(
        string path,
        IReadOnlyList<PeriodSummaryRow> rows,
        DateOnly from,
        DateOnly to)
    {
        Document.Create(document =>
        {
            document.Page(page =>
            {
                page.Size(PageSizes.A4.Landscape());
                page.Margin(28);
                page.DefaultTextStyle(style => style.FontFamily("Arial").FontSize(9).FontColor(Text));
                page.Header().Column(column =>
                {
                    column.Item().Text("CAMPUS PAY").FontSize(18).Bold().FontColor(Primary);
                    column.Item().Text("Начисления и оплаты за период").FontSize(14).Bold();
                    column.Item().Text($"{from:dd.MM.yyyy} — {to:dd.MM.yyyy}").FontColor(Muted);
                    column.Item().PaddingTop(8).LineHorizontal(1).LineColor(Border);
                });
                page.Content().PaddingTop(12).Table(table =>
                {
                    table.ColumnsDefinition(columns =>
                    {
                        columns.RelativeColumn(1.1f);
                        columns.RelativeColumn(2.2f);
                        columns.RelativeColumn(0.9f);
                        columns.RelativeColumn(1.1f);
                        columns.RelativeColumn(1.1f);
                        columns.RelativeColumn(1.1f);
                    });
                    table.Header(header =>
                    {
                        HeaderCell(header, "№ билета");
                        HeaderCell(header, "Студент");
                        HeaderCell(header, "Группа");
                        HeaderCell(header, "Начислено");
                        HeaderCell(header, "Оплачено");
                        HeaderCell(header, "Разница");
                    });
                    foreach (var row in rows)
                    {
                        BodyCell(table, row.StudentNumber);
                        BodyCell(table, row.StudentName);
                        BodyCell(table, row.GroupName);
                        BodyCell(table, $"{row.Accrued:N2}", true);
                        BodyCell(table, $"{row.Paid:N2}", true);
                        BodyCell(table, $"{row.Difference:N2}", true);
                    }
                    FooterCell(table, "ИТОГО", 3);
                    FooterCell(table, $"{rows.Sum(item => item.Accrued):N2}");
                    FooterCell(table, $"{rows.Sum(item => item.Paid):N2}");
                    FooterCell(table, $"{rows.Sum(item => item.Difference):N2}");
                });
                page.Footer().AlignCenter().Text(text =>
                {
                    text.Span("Страница ");
                    text.CurrentPageNumber();
                    text.Span(" из ");
                    text.TotalPages();
                });
            });
        }).GeneratePdf(path);
    }

    public void ExportReceipt(string path, StudentStatement statement)
    {
        Document.Create(document =>
        {
            document.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(32);
                page.DefaultTextStyle(style => style.FontFamily("Arial").FontSize(10).FontColor(Text));
                page.Header().Row(row =>
                {
                    row.RelativeItem().Column(column =>
                    {
                        column.Item().Text("CAMPUS PAY").FontSize(20).Bold().FontColor(Primary);
                        column.Item().Text("Квитанция за проживание в общежитии").FontSize(13).Bold();
                    });
                    row.ConstantItem(150).AlignRight().Column(column =>
                    {
                        column.Item().AlignRight().Text($"от {DateTime.Today:dd.MM.yyyy}").FontColor(Muted);
                        column.Item().AlignRight().Text($"Лицевой счёт: {statement.StudentNumber}").Bold();
                    });
                });
                page.Content().PaddingTop(18).Column(column =>
                {
                    column.Spacing(12);
                    column.Item().Background("F8FAFC").Border(1).BorderColor(Border).Padding(14).Column(info =>
                    {
                        info.Item().Text(statement.StudentName).FontSize(13).Bold();
                        info.Item().Text($"Группа: {statement.GroupName}");
                        info.Item().Text($"Место проживания: {statement.Residence}");
                        info.Item().Text($"Расчётный период: {statement.From:dd.MM.yyyy} — {statement.To:dd.MM.yyyy}");
                    });

                    column.Item().Text("Начисления").FontSize(12).Bold();
                    column.Item().Table(table =>
                    {
                        table.ColumnsDefinition(columns =>
                        {
                            columns.RelativeColumn(1);
                            columns.RelativeColumn(2);
                            columns.RelativeColumn(1);
                            columns.RelativeColumn(1);
                            columns.RelativeColumn(1);
                        });
                        table.Header(header =>
                        {
                            HeaderCell(header, "Период");
                            HeaderCell(header, "Услуга");
                            HeaderCell(header, "Начислено");
                            HeaderCell(header, "Оплачено");
                            HeaderCell(header, "Остаток");
                        });
                        foreach (var line in statement.Accruals)
                        {
                            BodyCell(table, line.Period.ToString("MM.yyyy"));
                            BodyCell(table, line.ServiceType);
                            BodyCell(table, line.Amount.ToString("N2"), true);
                            BodyCell(table, line.Paid.ToString("N2"), true);
                            BodyCell(table, line.Outstanding.ToString("N2"), true);
                        }
                    });

                    column.Item().Text("Платежи").FontSize(12).Bold();
                    column.Item().Table(table =>
                    {
                        table.ColumnsDefinition(columns =>
                        {
                            columns.RelativeColumn(1);
                            columns.RelativeColumn(1.3f);
                            columns.RelativeColumn(1.5f);
                            columns.RelativeColumn(1);
                            columns.RelativeColumn(1);
                        });
                        table.Header(header =>
                        {
                            HeaderCell(header, "Дата");
                            HeaderCell(header, "Документ");
                            HeaderCell(header, "Способ");
                            HeaderCell(header, "Сумма");
                            HeaderCell(header, "Аванс");
                        });
                        foreach (var line in statement.Payments)
                        {
                            BodyCell(table, line.PaymentDate.ToString("dd.MM.yyyy"));
                            BodyCell(table, line.DocumentNumber);
                            BodyCell(table, line.Method);
                            BodyCell(table, line.Amount.ToString("N2"), true);
                            BodyCell(table, line.Advance.ToString("N2"), true);
                        }
                    });

                    column.Item().Background("EEF2FF").Border(1).BorderColor("C7D2FE").Padding(16).Column(total =>
                    {
                        total.Item().Row(row =>
                        {
                            row.RelativeItem().Text("Основной долг");
                            row.ConstantItem(150).AlignRight().Text($"{statement.Debt.PrincipalDebt:N2} руб.").Bold();
                        });
                        total.Item().Row(row =>
                        {
                            row.RelativeItem().Text("Пени");
                            row.ConstantItem(150).AlignRight().Text($"{statement.Debt.Penalty:N2} руб.").Bold();
                        });
                        total.Item().PaddingTop(6).LineHorizontal(1).LineColor("C7D2FE");
                        total.Item().PaddingTop(6).Row(row =>
                        {
                            row.RelativeItem().Text("ИТОГО К ОПЛАТЕ").FontSize(13).Bold().FontColor(Primary);
                            row.ConstantItem(180).AlignRight().Text($"{statement.Debt.TotalPayable:N2} руб.").FontSize(14).Bold().FontColor(Primary);
                        });
                    });
                });
                page.Footer().AlignCenter().Text("Документ сформирован информационной системой Campus Pay").FontSize(8).FontColor(Muted);
            });
        }).GeneratePdf(path);
    }

    private static void HeaderCell(TableCellDescriptor header, string text) =>
        header.Cell().Background(Primary).Padding(7).Text(text).Bold().FontColor(Colors.White);

    private static void BodyCell(TableDescriptor table, string text, bool alignRight = false)
    {
        var container = table.Cell().BorderBottom(1).BorderColor(Border).Padding(6);
        if (alignRight)
        {
            container = container.AlignRight();
        }
        container.Text(text);
    }

    private static void FooterCell(TableDescriptor table, string text, uint columnSpan = 1)
    {
        var cell = table.Cell().ColumnSpan(columnSpan).Background("F1F5F9").Padding(7);
        cell.AlignRight().Text(text).Bold();
    }
}
