using System.Drawing.Imaging;
using DormitoryPayments.Application.Finance;
using DormitoryPayments.Application.Housing;
using DormitoryPayments.Application.Reporting;
using DormitoryPayments.Application.Security;
using DormitoryPayments.Application.Students;
using DormitoryPayments.WinForms.Forms;
using DormitoryPayments.WinForms.UI;
using Microsoft.Extensions.DependencyInjection;

namespace DormitoryPayments.WinForms.Services;

internal sealed class ScreenshotGenerator(
    IServiceProvider serviceProvider,
    IAuthenticationService authenticationService,
    IReportingService reportingService,
    ReportExportService exportService)
{
    public async Task GenerateAsync(string rootDirectory)
    {
        var screenshotDirectory = Path.Combine(rootDirectory, "screenshots");
        var sampleDirectory = Path.Combine(rootDirectory, "docs", "samples");
        Directory.CreateDirectory(screenshotDirectory);
        Directory.CreateDirectory(sampleDirectory);

        using (var loginForm = serviceProvider.GetRequiredService<LoginForm>())
        {
            loginForm.Show();
            PumpMessages(600);
            Capture(loginForm, Path.Combine(screenshotDirectory, "01_Окно_входа.png"));
            loginForm.Close();
            PumpMessages(150);
        }

        var authentication = await authenticationService.SignInAsync("admin", "Admin123!");
        if (!authentication.IsSuccess)
        {
            throw new InvalidOperationException($"Не удалось выполнить демонстрационный вход: {authentication.ErrorMessage}");
        }

        using (var mainForm = serviceProvider.GetRequiredService<MainForm>())
        {
            mainForm.WindowState = FormWindowState.Normal;
            mainForm.StartPosition = FormStartPosition.Manual;
            mainForm.Location = new Point(40, 40);
            mainForm.ClientSize = new Size(1440, 900);
            mainForm.Show();
            PumpMessages(1800);

            var pages = new[]
            {
                ("Обзор", "02_Главная_панель.png"),
                ("Студенты", "03_Справочник_студентов.png"),
                ("Жилой фонд", "04_Жилой_фонд.png"),
                ("Начисления", "05_Начисления.png"),
                ("Платежи", "06_Платежи.png"),
                ("Отчёты", "07_Задолженность_и_отчеты.png"),
                ("Пользователи", "08_Пользователи_и_аудит.png")
            };

            var navigationButtons = FindControls<NavigationButton>(mainForm).ToList();
            foreach (var page in pages)
            {
                var button = navigationButtons.FirstOrDefault(item => item.Text.Contains(page.Item1, StringComparison.Ordinal));
                button?.PerformClick();
                PumpMessages(page.Item1 == "Обзор" ? 7000 : 850);
                Capture(mainForm, Path.Combine(screenshotDirectory, page.Item2));

                if (page.Item1 == "Жилой фонд")
                {
                    CaptureSubpage(mainForm, "Комнаты", screenshotDirectory, "10_Комнаты.png");
                    CaptureSubpage(mainForm, "Заселения", screenshotDirectory, "11_Заселения.png");
                }
                else if (page.Item1 == "Начисления")
                {
                    CaptureSubpage(mainForm, "Тарифы", screenshotDirectory, "12_Тарифы.png");
                }
                else if (page.Item1 == "Отчёты")
                {
                    CaptureSubpage(mainForm, "Отчёт за период", screenshotDirectory, "13_Отчет_за_период.png");
                    CaptureSubpage(mainForm, "Аналитика", screenshotDirectory, "09_Аналитика.png", 1200);
                }
                else if (page.Item1 == "Пользователи")
                {
                    CaptureSubpage(mainForm, "Журнал действий", screenshotDirectory, "14_Журнал_действий.png");
                }
            }

            mainForm.Close();
            PumpMessages(200);
        }

        CaptureEditForms(screenshotDirectory);

        await GenerateSampleReportsAsync(sampleDirectory);
    }

    private void CaptureEditForms(string screenshotDirectory)
    {
        using (var form = new StudentEditForm(serviceProvider.GetRequiredService<IStudentService>(), null))
        {
            ShowAndCapture(form, Path.Combine(screenshotDirectory, "15_Карточка_студента.png"), 350);
        }

        using (var form = new AccommodationEditForm(serviceProvider.GetRequiredService<IHousingService>(), null))
        {
            ShowAndCapture(form, Path.Combine(screenshotDirectory, "16_Новое_заселение.png"), 900);
        }

        using (var form = new GenerateAccrualsForm(serviceProvider.GetRequiredService<IFinanceService>()))
        {
            ShowAndCapture(form, Path.Combine(screenshotDirectory, "17_Формирование_начислений.png"), 900);
        }

        using (var form = new PaymentEditForm(serviceProvider.GetRequiredService<IFinanceService>()))
        {
            ShowAndCapture(form, Path.Combine(screenshotDirectory, "18_Регистрация_платежа.png"), 900);
        }
    }

    private async Task GenerateSampleReportsAsync(string outputDirectory)
    {
        var today = DateOnly.FromDateTime(DateTime.Today);
        var from = new DateOnly(today.Year, today.Month, 1).AddMonths(-2);
        var rows = await reportingService.GetPeriodSummaryAsync(from, today, null);
        exportService.ExportPeriodToExcel(
            Path.Combine(outputDirectory, "Пример_отчета_за_период.xlsx"),
            rows,
            from,
            today);
        exportService.ExportPeriodToPdf(
            Path.Combine(outputDirectory, "Пример_отчета_за_период.pdf"),
            rows,
            from,
            today);

        var debts = await reportingService.GetDebtsAsync(null, today, 0.10m);
        if (debts.Count == 0)
        {
            return;
        }
        var statement = await reportingService.GetStudentStatementAsync(
            debts[0].StudentId,
            from,
            today,
            today,
            0.10m);
        exportService.ExportReceipt(
            Path.Combine(outputDirectory, "Пример_квитанции.pdf"),
            statement);
    }

    private static IEnumerable<T> FindControls<T>(Control root) where T : Control
    {
        foreach (Control child in root.Controls)
        {
            if (child is T match)
            {
                yield return match;
            }
            foreach (var nested in FindControls<T>(child))
            {
                yield return nested;
            }
        }
    }

    private static void Capture(Form form, string path)
    {
        form.Refresh();
        using var bitmap = new Bitmap(form.ClientSize.Width, form.ClientSize.Height);
        form.DrawToBitmap(bitmap, new Rectangle(Point.Empty, form.ClientSize));
        bitmap.Save(path, ImageFormat.Png);
    }

    private static void CaptureSubpage(
        Form form,
        string buttonText,
        string outputDirectory,
        string fileName,
        int delay = 850)
    {
        var button = FindControls<RoundedButton>(form)
            .FirstOrDefault(item => string.Equals(item.Text, buttonText, StringComparison.Ordinal));
        if (button is null)
        {
            return;
        }

        button.PerformClick();
        PumpMessages(delay);
        Capture(form, Path.Combine(outputDirectory, fileName));
    }

    private static void ShowAndCapture(Form form, string path, int delay)
    {
        form.Show();
        PumpMessages(delay);
        Capture(form, path);
        form.Close();
        PumpMessages(120);
    }

    private static void PumpMessages(int milliseconds)
    {
        var until = DateTime.UtcNow.AddMilliseconds(milliseconds);
        while (DateTime.UtcNow < until)
        {
            System.Windows.Forms.Application.DoEvents();
            Thread.Sleep(15);
        }
    }
}
