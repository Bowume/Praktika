using DormitoryPayments.Application.Dashboard;
using DormitoryPayments.Domain.Enums;
using DormitoryPayments.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace DormitoryPayments.Infrastructure.Dashboard;

public sealed class DashboardService(
    IDbContextFactory<DormitoryPaymentsDbContext> contextFactory) : IDashboardService
{
    public async Task<DashboardSnapshot> GetSnapshotAsync(CancellationToken cancellationToken = default)
    {
        var today = DateOnly.FromDateTime(DateTime.Today);
        var period = new DateOnly(today.Year, today.Month, 1);
        var monthEnd = period.AddMonths(1).AddDays(-1);
        await using var context = await contextFactory.CreateDbContextAsync(cancellationToken);

        var activeStudents = await context.Students.CountAsync(item => item.IsActive, cancellationToken);
        var roomData = await context.Rooms.AsNoTracking()
            .Where(item => item.IsActive)
            .Select(item => new
            {
                item.Capacity,
                Occupied = item.Accommodations.Count(accommodation => accommodation.StartDate <= today &&
                    (accommodation.EndDate == null || accommodation.EndDate >= today))
            })
            .ToListAsync(cancellationToken);
        var currentAccrued = await context.Accruals.AsNoTracking()
            .Where(item => item.Period == period && item.Status != AccrualStatus.Cancelled)
            .SumAsync(item => (decimal?)item.Amount, cancellationToken) ?? 0;
        var currentPaid = await context.Payments.AsNoTracking()
            .Where(item => item.PaymentDate >= period && item.PaymentDate <= monthEnd)
            .SumAsync(item => (decimal?)item.Amount, cancellationToken) ?? 0;
        var allAccrued = await context.Accruals.AsNoTracking()
            .Where(item => item.Status != AccrualStatus.Cancelled)
            .SumAsync(item => (decimal?)item.Amount, cancellationToken) ?? 0;
        var allPaid = await context.Payments.AsNoTracking()
            .SumAsync(item => (decimal?)item.Amount, cancellationToken) ?? 0;
        var recentPayments = await context.Payments.AsNoTracking()
            .OrderByDescending(item => item.PaymentDate)
            .ThenByDescending(item => item.Id)
            .Take(6)
            .Select(item => new RecentPaymentItem(
                item.PaymentDate,
                item.Student.LastName + " " + item.Student.FirstName,
                item.DocumentNumber,
                item.Amount))
            .ToListAsync(cancellationToken);

        return new DashboardSnapshot(
            activeStudents,
            roomData.Count,
            roomData.Sum(item => item.Occupied),
            roomData.Sum(item => item.Capacity),
            currentAccrued,
            currentPaid,
            Math.Max(0, allAccrued - allPaid),
            recentPayments);
    }
}
