using DormitoryPayments.Application.Calculations;
using DormitoryPayments.Application.Common;
using DormitoryPayments.Application.Reporting;
using DormitoryPayments.Domain.Enums;
using DormitoryPayments.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace DormitoryPayments.Infrastructure.Reporting;

public sealed class ReportingService(
    IDbContextFactory<DormitoryPaymentsDbContext> contextFactory) : IReportingService
{
    public async Task<IReadOnlyList<DebtRow>> GetDebtsAsync(
        string? search,
        DateOnly asOfDate,
        decimal annualPenaltyRate,
        CancellationToken cancellationToken = default)
    {
        var term = search?.Trim();
        await using var context = await contextFactory.CreateDbContextAsync(cancellationToken);
        var studentQuery = context.Students.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(term))
        {
            studentQuery = studentQuery.Where(item =>
                item.StudentNumber.Contains(term) || item.LastName.Contains(term) ||
                item.FirstName.Contains(term) || item.GroupName.Contains(term));
        }
        var students = await studentQuery
            .Select(item => new { item.Id, item.StudentNumber, item.LastName, item.FirstName, item.Patronymic, item.GroupName })
            .ToListAsync(cancellationToken);
        var studentIds = students.Select(item => item.Id).ToArray();

        var accruals = await context.Accruals.AsNoTracking()
            .Include(item => item.Allocations)
            .ThenInclude(item => item.Payment)
            .Where(item => studentIds.Contains(item.StudentId) && item.Period <= asOfDate &&
                item.Status != AccrualStatus.Cancelled)
            .ToListAsync(cancellationToken);
        var paymentTotals = await context.Payments.AsNoTracking()
            .Where(item => studentIds.Contains(item.StudentId) && item.PaymentDate <= asOfDate)
            .GroupBy(item => item.StudentId)
            .Select(group => new { StudentId = group.Key, Amount = group.Sum(item => item.Amount) })
            .ToDictionaryAsync(item => item.StudentId, item => item.Amount, cancellationToken);

        var accrualsByStudent = accruals.ToLookup(item => item.StudentId);
        return students
            .Select(student =>
            {
                var items = accrualsByStudent[student.Id]
                    .Select(accrual => new DebtAccrualItem(
                        accrual.Id,
                        accrual.DueDate,
                        accrual.Amount,
                        accrual.Allocations
                            .Where(allocation => allocation.Payment.PaymentDate <= asOfDate)
                            .Select(allocation => new DebtAllocationItem(
                                allocation.Payment.PaymentDate,
                                allocation.Amount))
                            .ToList()))
                    .ToList();
                var payments = paymentTotals.GetValueOrDefault(student.Id);
                var calculation = DebtCalculator.Calculate(items, payments, asOfDate, annualPenaltyRate);
                var fullName = string.Join(" ", new[] { student.LastName, student.FirstName, student.Patronymic }
                    .Where(item => !string.IsNullOrWhiteSpace(item)));
                return new DebtRow(
                    student.Id,
                    student.StudentNumber,
                    fullName,
                    student.GroupName,
                    calculation.TotalAccrued,
                    calculation.TotalPaid,
                    calculation.PrincipalDebt,
                    calculation.Advance,
                    calculation.Penalty,
                    calculation.TotalPayable);
            })
            .Where(item => item.Accrued != 0 || item.Paid != 0)
            .OrderByDescending(item => item.TotalPayable)
            .ThenBy(item => item.StudentName)
            .ToList();
    }

    public async Task<IReadOnlyList<PeriodSummaryRow>> GetPeriodSummaryAsync(
        DateOnly from,
        DateOnly to,
        int? studentId,
        CancellationToken cancellationToken = default)
    {
        var firstPeriod = new DateOnly(from.Year, from.Month, 1);
        var lastPeriod = new DateOnly(to.Year, to.Month, 1);
        await using var context = await contextFactory.CreateDbContextAsync(cancellationToken);
        var students = await context.Students.AsNoTracking()
            .Where(item => studentId == null || item.Id == studentId)
            .Select(item => new { item.Id, item.StudentNumber, item.LastName, item.FirstName, item.GroupName })
            .ToListAsync(cancellationToken);
        var ids = students.Select(item => item.Id).ToArray();
        var accruals = await context.Accruals.AsNoTracking()
            .Where(item => ids.Contains(item.StudentId) && item.Period >= firstPeriod &&
                item.Period <= lastPeriod && item.Status != AccrualStatus.Cancelled)
            .GroupBy(item => item.StudentId)
            .Select(group => new { StudentId = group.Key, Amount = group.Sum(item => item.Amount) })
            .ToDictionaryAsync(item => item.StudentId, item => item.Amount, cancellationToken);
        var payments = await context.Payments.AsNoTracking()
            .Where(item => ids.Contains(item.StudentId) && item.PaymentDate >= from && item.PaymentDate <= to)
            .GroupBy(item => item.StudentId)
            .Select(group => new { StudentId = group.Key, Amount = group.Sum(item => item.Amount) })
            .ToDictionaryAsync(item => item.StudentId, item => item.Amount, cancellationToken);

        return students
            .Select(student =>
            {
                var accrued = accruals.GetValueOrDefault(student.Id);
                var paid = payments.GetValueOrDefault(student.Id);
                return new PeriodSummaryRow(
                    student.Id,
                    student.StudentNumber,
                    student.LastName + " " + student.FirstName,
                    student.GroupName,
                    accrued,
                    paid,
                    accrued - paid);
            })
            .Where(item => item.Accrued != 0 || item.Paid != 0)
            .OrderBy(item => item.StudentName)
            .ToList();
    }

    public async Task<AnalyticsSnapshot> GetAnalyticsAsync(
        DateOnly from,
        DateOnly to,
        CancellationToken cancellationToken = default)
    {
        var firstPeriod = new DateOnly(from.Year, from.Month, 1);
        var lastPeriod = new DateOnly(to.Year, to.Month, 1);
        await using var context = await contextFactory.CreateDbContextAsync(cancellationToken);
        var accruals = await context.Accruals.AsNoTracking()
            .Where(item => item.Period >= firstPeriod && item.Period <= lastPeriod &&
                item.Status != AccrualStatus.Cancelled)
            .GroupBy(item => item.Period)
            .Select(group => new { Period = group.Key, Amount = group.Sum(item => item.Amount) })
            .ToListAsync(cancellationToken);
        var payments = await context.Payments.AsNoTracking()
            .Where(item => item.PaymentDate >= from && item.PaymentDate <= to)
            .GroupBy(item => new { item.PaymentDate.Year, item.PaymentDate.Month })
            .Select(group => new { group.Key.Year, group.Key.Month, Amount = group.Sum(item => item.Amount) })
            .ToListAsync(cancellationToken);

        var accrualByMonth = accruals.ToDictionary(item => item.Period, item => item.Amount);
        var paymentByMonth = payments.ToDictionary(
            item => new DateOnly(item.Year, item.Month, 1),
            item => item.Amount);
        var months = new List<MonthlySummary>();
        var cumulativeDebt = 0m;
        for (var period = firstPeriod; period <= lastPeriod; period = period.AddMonths(1))
        {
            var accrued = accrualByMonth.GetValueOrDefault(period);
            var paid = paymentByMonth.GetValueOrDefault(period);
            cumulativeDebt = Math.Max(0, cumulativeDebt + accrued - paid);
            months.Add(new MonthlySummary(period, accrued, paid, cumulativeDebt));
        }

        return new AnalyticsSnapshot(
            months,
            StatisticsCalculator.Calculate(months.Select(item => item.Accrued)),
            StatisticsCalculator.Calculate(months.Select(item => item.Paid)),
            StatisticsCalculator.Calculate(months.Select(item => item.Debt)));
    }

    public async Task<StudentStatement> GetStudentStatementAsync(
        int studentId,
        DateOnly from,
        DateOnly to,
        DateOnly asOfDate,
        decimal annualPenaltyRate,
        CancellationToken cancellationToken = default)
    {
        var firstPeriod = new DateOnly(from.Year, from.Month, 1);
        var lastPeriod = new DateOnly(to.Year, to.Month, 1);
        await using var context = await contextFactory.CreateDbContextAsync(cancellationToken);
        var student = await context.Students.AsNoTracking()
            .SingleOrDefaultAsync(item => item.Id == studentId, cancellationToken)
            ?? throw new InvalidOperationException("Студент не найден.");
        var residence = await context.Accommodations.AsNoTracking()
            .Where(item => item.StudentId == studentId && item.StartDate <= asOfDate &&
                (item.EndDate == null || item.EndDate >= asOfDate))
            .Select(item => item.Room.Dormitory.Name + ", комната " + item.Room.Number)
            .FirstOrDefaultAsync(cancellationToken) ?? "Не заселён";
        var accrualEntities = await context.Accruals.AsNoTracking()
            .Include(item => item.Tariff)
            .Include(item => item.Allocations)
            .ThenInclude(item => item.Payment)
            .Where(item => item.StudentId == studentId && item.Period >= firstPeriod &&
                item.Period <= lastPeriod && item.Status != AccrualStatus.Cancelled)
            .OrderBy(item => item.Period)
            .ToListAsync(cancellationToken);
        var paymentEntities = await context.Payments.AsNoTracking()
            .Include(item => item.Allocations)
            .Where(item => item.StudentId == studentId && item.PaymentDate >= from && item.PaymentDate <= to)
            .OrderBy(item => item.PaymentDate)
            .ToListAsync(cancellationToken);

        var allDebtAccruals = await context.Accruals.AsNoTracking()
            .Include(item => item.Allocations)
            .ThenInclude(item => item.Payment)
            .Where(item => item.StudentId == studentId && item.Period <= asOfDate &&
                item.Status != AccrualStatus.Cancelled)
            .ToListAsync(cancellationToken);
        var totalPayments = await context.Payments.AsNoTracking()
            .Where(item => item.StudentId == studentId && item.PaymentDate <= asOfDate)
            .SumAsync(item => (decimal?)item.Amount, cancellationToken) ?? 0;
        var debt = DebtCalculator.Calculate(
            allDebtAccruals.Select(item => new DebtAccrualItem(
                item.Id,
                item.DueDate,
                item.Amount,
                item.Allocations
                    .Where(allocation => allocation.Payment.PaymentDate <= asOfDate)
                    .Select(allocation => new DebtAllocationItem(allocation.Payment.PaymentDate, allocation.Amount))
                    .ToList())),
            totalPayments,
            asOfDate,
            annualPenaltyRate);

        var accrualLines = accrualEntities.Select(item =>
        {
            var paid = item.Allocations
                .Where(allocation => allocation.Payment.PaymentDate <= asOfDate)
                .Sum(allocation => allocation.Amount);
            return new AccrualStatementLine(
                item.Period,
                item.Tariff.ServiceType,
                item.DueDate,
                item.Amount,
                paid,
                Math.Max(0, item.Amount - paid));
        }).ToList();
        var paymentLines = paymentEntities.Select(item =>
        {
            var allocated = item.Allocations.Sum(allocation => allocation.Amount);
            return new PaymentStatementLine(
                item.PaymentDate,
                item.DocumentNumber,
                item.Method switch
                {
                    PaymentMethod.Cash => "Наличные",
                    PaymentMethod.BankCard => "Банковская карта",
                    _ => "Банковский перевод"
                },
                item.Amount,
                allocated,
                Math.Max(0, item.Amount - allocated));
        }).ToList();

        return new StudentStatement(
            student.Id,
            student.StudentNumber,
            student.FullName,
            student.GroupName,
            residence,
            from,
            to,
            accrualLines,
            paymentLines,
            debt);
    }

    public async Task<IReadOnlyList<LookupItem<int>>> GetStudentOptionsAsync(
        CancellationToken cancellationToken = default)
    {
        await using var context = await contextFactory.CreateDbContextAsync(cancellationToken);
        return await context.Students.AsNoTracking()
            .OrderBy(item => item.LastName)
            .ThenBy(item => item.FirstName)
            .Select(item => new LookupItem<int>(
                item.Id,
                item.LastName + " " + item.FirstName + " (" + item.StudentNumber + ")"))
            .ToListAsync(cancellationToken);
    }
}
