using System.Net.Http.Json;
using System.Text.Json.Serialization;
using DormitoryPayments.Application.Integrations;

namespace DormitoryPayments.Infrastructure.Integrations;

public sealed class CbrCurrencyRateService(HttpClient httpClient) : ICurrencyRateService
{
    private static readonly string[] DisplayedCurrencies = ["USD", "EUR", "CNY"];

    public async Task<CurrencyRateResult> GetLatestRatesAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var response = await httpClient.GetFromJsonAsync<CbrResponse>("/daily_json.js", cancellationToken);
            if (response is null)
            {
                return CurrencyRateResult.Failure("Сервис курсов валют вернул пустой ответ.");
            }

            var rates = DisplayedCurrencies
                .Where(code => response.Currencies.ContainsKey(code))
                .Select(code => response.Currencies[code])
                .Select(item => new CurrencyRate(
                    item.Code,
                    item.Name,
                    item.Nominal,
                    item.Value,
                    item.Previous))
                .ToList();
            return CurrencyRateResult.Success(response.Date, rates);
        }
        catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            return CurrencyRateResult.Failure("Сервис курсов валют не ответил за отведённое время.");
        }
        catch (HttpRequestException)
        {
            return CurrencyRateResult.Failure("Нет соединения с сервисом курсов валют.");
        }
        catch (Exception exception) when (exception is System.Text.Json.JsonException or NotSupportedException)
        {
            return CurrencyRateResult.Failure("Не удалось обработать ответ сервиса курсов валют.");
        }
    }

    private sealed record CbrResponse(
        [property: JsonPropertyName("Date")] DateTime Date,
        [property: JsonPropertyName("Valute")] Dictionary<string, CbrRate> Currencies);

    private sealed record CbrRate(
        [property: JsonPropertyName("CharCode")] string Code,
        [property: JsonPropertyName("Name")] string Name,
        [property: JsonPropertyName("Nominal")] int Nominal,
        [property: JsonPropertyName("Value")] decimal Value,
        [property: JsonPropertyName("Previous")] decimal Previous);
}
