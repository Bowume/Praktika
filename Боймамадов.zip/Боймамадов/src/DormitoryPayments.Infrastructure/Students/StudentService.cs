using DormitoryPayments.Application.Common;
using DormitoryPayments.Application.Security;
using DormitoryPayments.Application.Students;
using DormitoryPayments.Domain.Entities;
using DormitoryPayments.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace DormitoryPayments.Infrastructure.Students;

public sealed class StudentService(
    IDbContextFactory<DormitoryPaymentsDbContext> contextFactory,
    IUserSession session) : IStudentService
{
    public async Task<PagedResult<StudentRow>> GetPageAsync(
        string? search,
        bool includeInactive,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default)
    {
        page = Math.Max(1, page);
        pageSize = Math.Clamp(pageSize, 10, 100);
        var searchTerm = search?.Trim();
        var today = DateOnly.FromDateTime(DateTime.Today);

        await using var context = await contextFactory.CreateDbContextAsync(cancellationToken);
        var query = context.Students.AsNoTracking();
        if (!includeInactive)
        {
            query = query.Where(item => item.IsActive);
        }

        if (!string.IsNullOrWhiteSpace(searchTerm))
        {
            query = query.Where(item =>
                item.StudentNumber.Contains(searchTerm) ||
                item.LastName.Contains(searchTerm) ||
                item.FirstName.Contains(searchTerm) ||
                item.GroupName.Contains(searchTerm));
        }

        var totalCount = await query.CountAsync(cancellationToken);
        var items = await query
            .OrderBy(item => item.LastName)
            .ThenBy(item => item.FirstName)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(item => new StudentRow(
                item.Id,
                item.StudentNumber,
                item.LastName + " " + item.FirstName + (item.Patronymic == null ? "" : " " + item.Patronymic),
                item.GroupName,
                item.Phone ?? "—",
                item.Email ?? "—",
                item.Accommodations
                    .Where(accommodation => accommodation.StartDate <= today &&
                        (accommodation.EndDate == null || accommodation.EndDate >= today))
                    .Select(accommodation => accommodation.Room.Dormitory.Name + ", комн. " + accommodation.Room.Number)
                    .FirstOrDefault() ?? "Не заселён",
                item.IsActive))
            .ToListAsync(cancellationToken);

        return new PagedResult<StudentRow>(items, page, pageSize, totalCount);
    }

    public async Task<StudentInput?> GetAsync(int id, CancellationToken cancellationToken = default)
    {
        await using var context = await contextFactory.CreateDbContextAsync(cancellationToken);
        return await context.Students
            .AsNoTracking()
            .Where(item => item.Id == id)
            .Select(item => new StudentInput(
                item.Id,
                item.StudentNumber,
                item.LastName,
                item.FirstName,
                item.Patronymic,
                item.GroupName,
                item.Phone,
                item.Email,
                item.IsActive))
            .SingleOrDefaultAsync(cancellationToken);
    }

    public async Task<int> SaveAsync(StudentInput input, CancellationToken cancellationToken = default)
    {
        EnsureCanManage();
        StudentValidator.Validate(input);

        var number = input.StudentNumber.Trim();
        await using var context = await contextFactory.CreateDbContextAsync(cancellationToken);
        var duplicateExists = await context.Students.AnyAsync(
            item => item.StudentNumber == number && item.Id != input.Id,
            cancellationToken);
        if (duplicateExists)
        {
            throw new ValidationException("Студент с таким номером билета уже существует.");
        }

        Student entity;
        var action = "StudentCreated";
        if (input.Id is null)
        {
            entity = new Student();
            context.Students.Add(entity);
        }
        else
        {
            entity = await context.Students.SingleOrDefaultAsync(item => item.Id == input.Id, cancellationToken)
                ?? throw new ValidationException("Запись студента не найдена.");
            action = "StudentUpdated";
        }

        entity.StudentNumber = number;
        entity.LastName = input.LastName.Trim();
        entity.FirstName = input.FirstName.Trim();
        entity.Patronymic = NormalizeOptional(input.Patronymic);
        entity.GroupName = input.GroupName.Trim();
        entity.Phone = NormalizeOptional(input.Phone);
        entity.Email = NormalizeOptional(input.Email);
        entity.IsActive = input.IsActive;
        AddAudit(context, action, $"Студент: {entity.LastName} {entity.FirstName}, № {number}.");
        await context.SaveChangesAsync(cancellationToken);
        return entity.Id;
    }

    public async Task ArchiveAsync(int id, CancellationToken cancellationToken = default)
    {
        EnsureCanManage();
        await using var context = await contextFactory.CreateDbContextAsync(cancellationToken);
        var entity = await context.Students.SingleOrDefaultAsync(item => item.Id == id, cancellationToken)
            ?? throw new ValidationException("Запись студента не найдена.");
        if (await context.Accommodations.AnyAsync(
                item => item.StudentId == id && item.EndDate == null,
                cancellationToken))
        {
            throw new ValidationException("Сначала оформите выселение студента из комнаты.");
        }

        entity.IsActive = false;
        AddAudit(context, "StudentArchived", $"Студент № {entity.StudentNumber} переведён в архив.");
        await context.SaveChangesAsync(cancellationToken);
    }

    private void EnsureCanManage()
    {
        if (!session.HasPermission(Permission.ManageStudents))
        {
            throw new UnauthorizedAccessException("Недостаточно прав для изменения справочника студентов.");
        }
    }

    private void AddAudit(DormitoryPaymentsDbContext context, string action, string details) =>
        context.AuditLogs.Add(new AuditLog
        {
            UserId = session.CurrentUser?.Id,
            TimestampUtc = DateTime.UtcNow,
            Level = "Information",
            Action = action,
            Details = details
        });

    private static string? NormalizeOptional(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
