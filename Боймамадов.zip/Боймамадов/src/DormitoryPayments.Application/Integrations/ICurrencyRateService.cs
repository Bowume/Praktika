namespace DormitoryPayments.Application.Integrations;

public interface ICurrencyRateService
{
    Task<CurrencyRateResult> GetLatestRatesAsync(CancellationToken cancellationToken = default);
}
