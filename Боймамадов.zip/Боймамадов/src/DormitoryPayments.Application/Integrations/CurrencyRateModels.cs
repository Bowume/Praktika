namespace DormitoryPayments.Application.Integrations;

public sealed record CurrencyRate(
    string Code,
    string Name,
    int Nominal,
    decimal Value,
    decimal PreviousValue);

public sealed record CurrencyRateResult(
    bool IsSuccess,
    DateTime? RateDate,
    IReadOnlyList<CurrencyRate> Rates,
    string ErrorMessage)
{
    public static CurrencyRateResult Success(DateTime date, IReadOnlyList<CurrencyRate> rates) =>
        new(true, date, rates, string.Empty);

    public static CurrencyRateResult Failure(string message) =>
        new(false, null, [], message);
}
