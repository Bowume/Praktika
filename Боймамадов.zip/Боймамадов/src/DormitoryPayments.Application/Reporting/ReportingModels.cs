using DormitoryPayments.Application.Calculations;

namespace DormitoryPayments.Application.Reporting;

public sealed record DebtRow(
    int StudentId,
    string StudentNumber,
    string StudentName,
    string GroupName,
    decimal Accrued,
    decimal Paid,
    decimal PrincipalDebt,
    decimal Advance,
    decimal Penalty,
    decimal TotalPayable);

public sealed record PeriodSummaryRow(
    int StudentId,
    string StudentNumber,
    string StudentName,
    string GroupName,
    decimal Accrued,
    decimal Paid,
    decimal Difference);

public sealed record MonthlySummary(
    DateOnly Period,
    decimal Accrued,
    decimal Paid,
    decimal Debt);

public sealed record AccrualStatementLine(
    DateOnly Period,
    string ServiceType,
    DateOnly DueDate,
    decimal Amount,
    decimal Paid,
    decimal Outstanding);

public sealed record PaymentStatementLine(
    DateOnly PaymentDate,
    string DocumentNumber,
    string Method,
    decimal Amount,
    decimal Allocated,
    decimal Advance);

public sealed record StudentStatement(
    int StudentId,
    string StudentNumber,
    string StudentName,
    string GroupName,
    string Residence,
    DateOnly From,
    DateOnly To,
    IReadOnlyList<AccrualStatementLine> Accruals,
    IReadOnlyList<PaymentStatementLine> Payments,
    DebtCalculationResult Debt);

public sealed record AnalyticsSnapshot(
    IReadOnlyList<MonthlySummary> Months,
    StatisticsResult AccrualStatistics,
    StatisticsResult PaymentStatistics,
    StatisticsResult DebtStatistics);
