using DormitoryPayments.Application.Common;

namespace DormitoryPayments.Application.Reporting;

public interface IReportingService
{
    Task<IReadOnlyList<DebtRow>> GetDebtsAsync(
        string? search,
        DateOnly asOfDate,
        decimal annualPenaltyRate,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<PeriodSummaryRow>> GetPeriodSummaryAsync(
        DateOnly from,
        DateOnly to,
        int? studentId,
        CancellationToken cancellationToken = default);

    Task<AnalyticsSnapshot> GetAnalyticsAsync(
        DateOnly from,
        DateOnly to,
        CancellationToken cancellationToken = default);

    Task<StudentStatement> GetStudentStatementAsync(
        int studentId,
        DateOnly from,
        DateOnly to,
        DateOnly asOfDate,
        decimal annualPenaltyRate,
        CancellationToken cancellationToken = default);

    Task<IReadOnlyList<LookupItem<int>>> GetStudentOptionsAsync(CancellationToken cancellationToken = default);
}
