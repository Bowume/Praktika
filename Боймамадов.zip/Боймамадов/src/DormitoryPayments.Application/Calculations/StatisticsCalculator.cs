namespace DormitoryPayments.Application.Calculations;

public sealed record StatisticsResult(
    int Count,
    decimal Sum,
    decimal Mean,
    decimal Variance,
    decimal Median,
    decimal Minimum,
    decimal Maximum);

public static class StatisticsCalculator
{
    public static StatisticsResult Calculate(IEnumerable<decimal> values)
    {
        var data = values.OrderBy(item => item).ToArray();
        if (data.Length == 0)
        {
            return new StatisticsResult(0, 0, 0, 0, 0, 0, 0);
        }

        var sum = data.Sum();
        var mean = sum / data.Length;
        var variance = data.Sum(item => (item - mean) * (item - mean)) / data.Length;
        var middle = data.Length / 2;
        var median = data.Length % 2 == 0
            ? (data[middle - 1] + data[middle]) / 2
            : data[middle];

        return new StatisticsResult(
            data.Length,
            Round(sum),
            Round(mean),
            Round(variance),
            Round(median),
            Round(data[0]),
            Round(data[^1]));
    }

    private static decimal Round(decimal value) =>
        decimal.Round(value, 2, MidpointRounding.AwayFromZero);
}
