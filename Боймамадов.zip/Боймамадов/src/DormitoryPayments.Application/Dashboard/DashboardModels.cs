namespace DormitoryPayments.Application.Dashboard;

public sealed record RecentPaymentItem(
    DateOnly Date,
    string StudentName,
    string DocumentNumber,
    decimal Amount);

public sealed record DashboardSnapshot(
    int ActiveStudents,
    int ActiveRooms,
    int OccupiedPlaces,
    int TotalPlaces,
    decimal CurrentMonthAccrued,
    decimal CurrentMonthPaid,
    decimal TotalDebt,
    IReadOnlyList<RecentPaymentItem> RecentPayments);
