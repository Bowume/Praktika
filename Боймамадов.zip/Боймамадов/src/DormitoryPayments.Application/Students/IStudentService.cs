using DormitoryPayments.Application.Common;

namespace DormitoryPayments.Application.Students;

public interface IStudentService
{
    Task<PagedResult<StudentRow>> GetPageAsync(
        string? search,
        bool includeInactive,
        int page,
        int pageSize,
        CancellationToken cancellationToken = default);

    Task<StudentInput?> GetAsync(int id, CancellationToken cancellationToken = default);

    Task<int> SaveAsync(StudentInput input, CancellationToken cancellationToken = default);

    Task ArchiveAsync(int id, CancellationToken cancellationToken = default);
}
