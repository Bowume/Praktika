using System.Net.Mail;
using System.Text.RegularExpressions;
using DormitoryPayments.Application.Common;

namespace DormitoryPayments.Application.Students;

public static partial class StudentValidator
{
    public static void Validate(StudentInput input)
    {
        if (string.IsNullOrWhiteSpace(input.StudentNumber))
        {
            throw new ValidationException("Укажите номер студенческого билета.");
        }

        if (input.StudentNumber.Trim().Length is < 3 or > 30)
        {
            throw new ValidationException("Номер студенческого билета должен содержать от 3 до 30 символов.");
        }

        if (string.IsNullOrWhiteSpace(input.LastName) || string.IsNullOrWhiteSpace(input.FirstName))
        {
            throw new ValidationException("Фамилия и имя являются обязательными.");
        }

        if (string.IsNullOrWhiteSpace(input.GroupName))
        {
            throw new ValidationException("Укажите учебную группу.");
        }

        if (!string.IsNullOrWhiteSpace(input.Phone) && !PhonePattern().IsMatch(input.Phone))
        {
            throw new ValidationException("Телефон может содержать цифры, пробелы и символы + ( ) -.");
        }

        if (!string.IsNullOrWhiteSpace(input.Email))
        {
            try
            {
                _ = new MailAddress(input.Email.Trim());
            }
            catch (FormatException)
            {
                throw new ValidationException("Укажите корректный адрес электронной почты.");
            }
        }
    }

    [GeneratedRegex(@"^[0-9+()\-\s]{7,30}$")]
    private static partial Regex PhonePattern();
}
