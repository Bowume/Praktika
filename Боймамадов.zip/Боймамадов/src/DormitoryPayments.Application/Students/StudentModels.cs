namespace DormitoryPayments.Application.Students;

public sealed record StudentRow(
    int Id,
    string StudentNumber,
    string FullName,
    string GroupName,
    string Phone,
    string Email,
    string Residence,
    bool IsActive);

public sealed record StudentInput(
    int? Id,
    string StudentNumber,
    string LastName,
    string FirstName,
    string? Patronymic,
    string GroupName,
    string? Phone,
    string? Email,
    bool IsActive = true);
