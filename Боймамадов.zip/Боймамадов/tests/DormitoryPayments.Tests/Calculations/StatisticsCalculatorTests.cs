using DormitoryPayments.Application.Calculations;
using FluentAssertions;

namespace DormitoryPayments.Tests.Calculations;

public sealed class StatisticsCalculatorTests
{
    [Fact]
    public void Calculate_ReturnsMeanVarianceAndMedian()
    {
        var result = StatisticsCalculator.Calculate([1m, 2m, 3m, 4m]);

        result.Count.Should().Be(4);
        result.Sum.Should().Be(10m);
        result.Mean.Should().Be(2.5m);
        result.Variance.Should().Be(1.25m);
        result.Median.Should().Be(2.5m);
        result.Minimum.Should().Be(1m);
        result.Maximum.Should().Be(4m);
    }

    [Fact]
    public void Calculate_HandlesEmptySequence()
    {
        StatisticsCalculator.Calculate([]).Should().Be(
            new StatisticsResult(0, 0, 0, 0, 0, 0, 0));
    }
}
