using DormitoryPayments.Application.Common;
using DormitoryPayments.Application.Students;
using FluentAssertions;

namespace DormitoryPayments.Tests.Students;

public sealed class StudentValidatorTests
{
    [Fact]
    public void Validate_AcceptsCorrectStudent()
    {
        var input = new StudentInput(
            null,
            "СТ-100",
            "Иванов",
            "Иван",
            "Иванович",
            "ИС-21",
            "+7 900 000-00-00",
            "student@example.ru");

        var action = () => StudentValidator.Validate(input);

        action.Should().NotThrow();
    }

    [Theory]
    [InlineData("bad phone", "student@example.ru")]
    [InlineData("+7 900 000-00-00", "not-an-email")]
    public void Validate_RejectsInvalidContacts(string phone, string email)
    {
        var input = new StudentInput(
            null,
            "СТ-100",
            "Иванов",
            "Иван",
            null,
            "ИС-21",
            phone,
            email);

        var action = () => StudentValidator.Validate(input);

        action.Should().Throw<ValidationException>();
    }
}
